using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FortManager : MonoBehaviour
{
    /*
    public Image fort_skin; //объект
    public int FORT; //взять из PlayerPrefs код
    public Sprite[] FORT_SKINS; //три прокачки форта, три состояния - целый, поврежден, сильно поврежден
    public Sprite[] CANNON_SKINS; //4 уровня прокачки каждой пушки

    public int maxHealth = 100;
    public int currentHealth = 100;

    // Start is called before the first frame update
    void Start()
    {
        if (!PlayerPrefs.HasKey("fort")) PlayerPrefs.SetInt("fort", 0); //0 - простой, 1 - улучшенный, 2 - лучший
        FORT = PlayerPrefs.GetInt("fort");
        fort_skin.sprite = FORT_SKINS[FORT * 3];
        maxHealth = 100*(FORT+1);

    }

    // Update is called once per frame
    void Update()
    {
    }

    void damage(int amount)
    {
        currentHealth -= amount;
        if (currentHealth < 0.75 * maxHealth)
        {
            if (currentHealth < 0.35 * maxHealth) fort_skin.sprite = FORT_SKINS[FORT * 3 + 2];
            else fort_skin.sprite = FORT_SKINS[FORT * 3 + 1];
            //if (currentHealth <=0) destroyFort();
        }
    }
    */
}
