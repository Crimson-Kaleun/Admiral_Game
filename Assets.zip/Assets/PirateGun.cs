using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PirateGun : MonoBehaviour
{
    // Start is called before the first frame update
    private Animator a;
    private Slider hp;
    
    public AudioClip gunSound;
    public AudioSource sndSrc; 
    void Start()
    {
        hp = GameObject.Find("HealthBar").GetComponent<Slider>();
        a=this.GetComponent<Animator>();
        testAngle();
        sndSrc.volume = 0.3f;
        sndSrc.clip = gunSound;
        shoot();
    }

    void testAngle()
    {
        float g = Quaternion.Angle(transform.rotation, Quaternion.Euler(0f, 0f, 0f));
        if (g>33f && g<60f && transform.position.x < 120) a.SetBool("Dir", true);
        else a.SetBool("Dir", false);
        Invoke("testAngle", 1f);
    }

    void shoot()
    {
        if (a.GetBool("Open") && a.GetBool("Dir")) {hp.value -= 0.5f + Random.Range(0.15f, 0.25f); sndSrc.Play();}
        Invoke("shoot", 0.3f + Random.Range(0.15f, 0.25f));
    }
}
