using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class ShopManager : MonoBehaviour
{
    public Image fort_skin_shop; //объект
    public Image cannon_01, cannon_02, cannon_03;
    public Image empty_01, empty_02, empty_03;

    public int FORT_SKIN; //взять из PlayerPrefs код
    public int CANNON_01_SKIN, CANNON_02_SKIN, CANNON_03_SKIN;

    public Sprite[] FORT_SHOP_SKINS, CANNON_SHOP_SKINS, BCKGR;
    public int money;
    public TextMeshProUGUI moneyCounter;
    int[] fort_prices = {700, 1000, 2000, 1000, 1200, 3000, 1500, 2000};
    int[,] cannon_prices =
    {
        {500, 200, 300, 400}, //дробаш
        {800, 300, 400, 500}, //пушка
        {1200, 400, 600, 800}, //цепная пушка
        {1500, 500, 700, 1000}, //снайперка
        {2000, 800, 1200, 1500} //взрывная
    };

    public GameObject shopFort, shopFortUpgrade, shopFortMax, shopCannons, upgradeCannon, maxButton, buyButton;
    //меню форт
    public Image Fort1, Fort2;
    public TextMeshProUGUI FortPrice;
    //меню апгрейд
    public Image cannonImg, cannonBack;
    public TextMeshProUGUI cannonBuyPrice, cannonSellPrice;

    public int cannonChosen = 0;

    public AudioClip[] audioMoneyArray;
    public AudioSource randomSound;


    int fx(int index)
    {
        if (index <= 1) return 0;
        if (index <= 5) return 1;
        return 2;
    }

    public void chooseCannon(int i) 
    {
        cannonChosen = i;
    }

    public void playSound()
    {
       randomSound.clip = audioMoneyArray[Random.Range(0, audioMoneyArray.Length)];
       randomSound.Play();
    }

    void Start()
    {
        if (!PlayerPrefs.HasKey("fort")) PlayerPrefs.SetInt("fort", 0); //0 - простой, 1 - улучшенный, 2 - лучший
        if (!PlayerPrefs.HasKey("cannon01")) PlayerPrefs.SetInt("cannon01", 0);
        if (!PlayerPrefs.HasKey("cannon02")) PlayerPrefs.SetInt("cannon02", 5);
        if (!PlayerPrefs.HasKey("cannon03")) PlayerPrefs.SetInt("cannon03", 0);
        if (!PlayerPrefs.HasKey("money")) PlayerPrefs.SetInt("money", 0);

        empty_01.enabled = false;
        empty_02.enabled = false;
        empty_03.enabled = false;

        fort_skin_shop.alphaHitTestMinimumThreshold = 0.5f;
        maxButton.SetActive(false);

        FORT_SKIN = PlayerPrefs.GetInt("fort", 0);
        CANNON_01_SKIN = PlayerPrefs.GetInt("cannon01", 0);
        CANNON_02_SKIN = PlayerPrefs.GetInt("cannon02", 5);
        CANNON_03_SKIN = PlayerPrefs.GetInt("cannon03", 0);
        money = PlayerPrefs.GetInt("money", 0);
        moneyCounter.text = money.ToString();
        fort_skin_shop.sprite = FORT_SHOP_SKINS[fx(FORT_SKIN)];
        cannon_01.sprite = CANNON_SHOP_SKINS[CANNON_01_SKIN];
        cannon_02.sprite = CANNON_SHOP_SKINS[CANNON_02_SKIN];
        cannon_03.sprite = CANNON_SHOP_SKINS[CANNON_03_SKIN];

        if (CANNON_01_SKIN == 0) {cannon_01.enabled = false; empty_01.enabled = true;} 
        if (CANNON_02_SKIN == 0) {cannon_02.enabled = false; empty_02.enabled = true;}
        if (CANNON_03_SKIN == 0) {cannon_03.enabled = false; empty_03.enabled = true;}

        
    }

    public bool changeMoney(int amount)
    {
        playSound();
        if (money>=amount) 
        {
            money -= amount;
            PlayerPrefs.SetInt("money", money);
            moneyCounter.text = money.ToString();
            return true;
        }
        return false;
    }


    public void fortUpgrade()
    {
        int i = PlayerPrefs.GetInt("fort", 0);
        if (changeMoney(fort_prices[i]))
        {
            PlayerPrefs.SetInt("fort", i + 1);
            fort_skin_shop.sprite = FORT_SHOP_SKINS[fx(i+1)];
            showFort();
        }
    }

    public void cannonUpgrade()
    {
        int currentCannon = PlayerPrefs.GetInt("cannon0" + (cannonChosen + 1).ToString());
        int cannon = currentCannon / 4, upgrade = currentCannon % 4; 
        if (changeMoney(cannon_prices[cannon, upgrade]))
        {
            if (cannonChosen==0) { 
                PlayerPrefs.SetInt("cannon01", currentCannon+1); 
                cannon_01.sprite = CANNON_SHOP_SKINS[currentCannon+1];
            }
            if (cannonChosen==1) { 
                PlayerPrefs.SetInt("cannon02", currentCannon+1); 
                cannon_02.sprite = CANNON_SHOP_SKINS[currentCannon+1];
            }
            if (cannonChosen==2) { 
                PlayerPrefs.SetInt("cannon03", currentCannon+1); 
                cannon_03.sprite = CANNON_SHOP_SKINS[currentCannon+1];
            }
        }
        showUpgrade();
    }

    public void cannonSell()
    {
        string a = "cannon0" + (cannonChosen + 1).ToString();
        int currentCannon = PlayerPrefs.GetInt(a) - 1;
        changeMoney(-cannon_prices[(currentCannon) / 4, 0]);
        PlayerPrefs.SetInt(a, 0);
        if (a=="cannon01") {cannon_01.enabled = false; empty_01.enabled = true;} 
        else if (a=="cannon02") {cannon_02.enabled = false; empty_02.enabled = true;} 
        else {cannon_03.enabled = false; empty_03.enabled = true;}
        showCannons();

    }

    public void cannonBuy(int cannon)
    {
        int price = cannon_prices[cannon, 0];
        if (changeMoney(price))
        {
            if (cannonChosen == 0) {
                PlayerPrefs.SetInt("cannon01", 1+cannon*4);
                CANNON_01_SKIN = 1 + cannon*4;
                cannon_01.sprite = CANNON_SHOP_SKINS[CANNON_01_SKIN];
                empty_01.enabled = false;
                cannon_01.enabled = true;
            }
            else if (cannonChosen == 1) {
                PlayerPrefs.SetInt("cannon02", 1+cannon*4);
                CANNON_02_SKIN = 1 + cannon*4;
                cannon_02.sprite = CANNON_SHOP_SKINS[CANNON_02_SKIN];
                empty_02.enabled = false;
                cannon_02.enabled = true;
            }
            else {
                PlayerPrefs.SetInt("cannon03", 1+cannon*4);
                CANNON_03_SKIN = 1 + cannon*4;
                cannon_03.sprite = CANNON_SHOP_SKINS[CANNON_03_SKIN];
                empty_03.enabled = false;
                cannon_03.enabled = true;
            }
            showUpgrade();
        }
    }

    public void hideAll()
    {
        shopFort.SetActive(false);
        upgradeCannon.SetActive(false);
        shopCannons.SetActive(false);
    }

    public void showCannons()
    {
        hideAll();
        shopCannons.SetActive(true);
    }

    public void showFort()
    {

        hideAll();
        shopFort.SetActive(true);
        FORT_SKIN = PlayerPrefs.GetInt("fort", 0);
        if (FORT_SKIN < 8)
        {
            shopFortMax.SetActive(false);
            shopFortUpgrade.SetActive(true);
            Fort1.sprite = FORT_SHOP_SKINS[fx(FORT_SKIN)];
            Fort2.sprite = FORT_SHOP_SKINS[fx(FORT_SKIN + 1)];
            FortPrice.text = fort_prices[FORT_SKIN].ToString();

        }
        else
        {
            shopFortUpgrade.SetActive(false);
            shopFortMax.SetActive(true);
        }
    }

    public void showUpgrade()
    {
        hideAll();
        upgradeCannon.SetActive(true);
        int currentCannon = PlayerPrefs.GetInt("cannon0" + (cannonChosen + 1).ToString());
        cannonImg.sprite = CANNON_SHOP_SKINS[currentCannon];
        System.Random rnd = new System.Random(currentCannon);
        cannonBack.sprite = BCKGR[rnd.Next(0, BCKGR.Length)];
        cannonSellPrice.text = cannon_prices[(currentCannon-1) / 4, 0].ToString();
        if ((currentCannon-1) % 4 != 3)
        {
            cannonBuyPrice.text = cannon_prices[(currentCannon-1) / 4, (currentCannon) % 4].ToString();
            cannonBuyPrice.enabled = true;
            buyButton.SetActive(true);
            maxButton.SetActive(false);
        }
        else
        {
            cannonBuyPrice.enabled = false;
            buyButton.SetActive(false);
            maxButton.SetActive(true);
        }
    }
}
