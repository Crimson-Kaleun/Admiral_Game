using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonballScript : MonoBehaviour
{
    private SpriteRenderer sp;
    // Start is called before the first frame update
    void Start()
    {
        sp = this.GetComponent<SpriteRenderer>();
        Invoke("fade", 5f);
    }

    void fade()
    {
        Color tmp = sp.color;
        tmp.a -= 0.02f;
        if (tmp.a>0.05f) 
        {
            sp.color = tmp;
            Invoke("fade", 0.05f);
        }
        else Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
         if (collision.collider.tag == "Pirateship") 
         {
            GameObject emptyObject = new GameObject();
            Destroy(emptyObject, 5f);
            emptyObject.transform.SetParent(collision.gameObject.transform, true);
            this.transform.SetParent(emptyObject.transform, true);
         }
    }
}
