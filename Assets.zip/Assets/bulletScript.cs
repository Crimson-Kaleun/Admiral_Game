using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletScript : MonoBehaviour
{
    public AudioSource a;
    public AudioClip[] c;
    private bool flag = true;

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Pirateship") 
        {
            if (flag)
            {
                a.clip = c[Random.Range(0,c.Length)];
                a.Play();
            }
            flag = false;
            this.GetComponent<SpriteRenderer>().enabled = false;
            Destroy(a, 1f);
            Destroy(gameObject, 1.2f);

        }
        else if (collision.collider.tag == "Pirate") flag = false;
    }
}
