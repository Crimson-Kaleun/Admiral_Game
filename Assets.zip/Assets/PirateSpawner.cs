using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PirateSpawner : MonoBehaviour
{
    public static int hard = 0; //[0-20]
    private int shipCount = 0;
    private static int shipSpawned = 0;
    private bool win = false;
    private float timeSpawn = 10f;
    public static float speed = 1f;

    public GameObject[] ships;
    public GameObject endgame;
    public float[] posX, posY;
    void Start()
    {
       shipCount = 5 + hard * hard + Random.Range(hard, 2*hard);
        speed = 1f + Mathf.Sqrt((float)hard);
        timeSpawn = 60f * (float)(hard + 1) / shipCount;
        checkVictory();
        spawnShip();
    }
    void checkVictory()
    {
         if (ShipController.shipDrown == shipCount)
         {
            Invoke("victory", 2f);
            win = true;
         }
         else Invoke("checkVictory", 3f);
    }

    void victory()
    {
        endgame.SetActive(true);
        endgame.GetComponent<Animator>().SetTrigger("gameover");
    }

    void spawnShip()
    {
        if (shipSpawned < shipCount && !win)
        {
            int ind = 0;
            Instantiate(ships[ind], new Vector3(posX[ind], posY[ind], 0f), Quaternion.Euler(0f, 0f, 0f));
            shipSpawned++;
            Invoke("spawnShip", timeSpawn);
        }
    }

}
