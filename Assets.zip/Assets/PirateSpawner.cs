using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PirateSpawner : MonoBehaviour
{
    public Slider healthSlider;
    public static int hard = 15; //[0-20]
    private int shipCount = 0;
    private static int shipSpawned = 0;
    private bool win = false;
    private float timeSpawn = 10f;
    private float time_delta = 1f;
    public static float speed = 1f;

    public GameObject[] ships_small, ships_middle, ships_large, ships_boss;
    public GameObject endgame;
    public float[] posY_small, posY_middle, posY_large, posY_boss;

    public AudioSource bckgrmusic;
    public AudioClip[] music;
    void Start()
    {
        shipCount = 5 + (int)Mathf.Pow((float)hard, (1.0f/3.0f)) * hard + Random.Range(0, hard);
        speed = 1f + Mathf.Sqrt((float)hard);

        if (hard <= 5) timeSpawn = 5f;
        else if (hard <= 10) timeSpawn = 6f;
        else if (hard <=15) timeSpawn = 12f;
        else timeSpawn = 13f;

        Debug.Log(shipCount);
        checkVictory();
        spawnShip();
    }
    void checkVictory()
    {
         if (ShipController.shipDrown == shipCount)
         {
            Invoke("victory", 2f);
            win = true;
         }
         else Invoke("checkVictory", 3f);
    }

    void victory()
    {
        endgame.SetActive(true);
        endgame.GetComponent<Animator>().SetTrigger("gameover");
    }

    void spawnShip()
    {
        if (shipSpawned < shipCount && !win && healthSlider.value > 0)
        {
            Invoke("spawnShip", time_delta + timeSpawn);
            if (hard <= 5)
            {
                if (Random.Range(0f,1f) <= 1f - hard / 25)
                {
                    int i = Random.Range(0,ships_small.Length);
                    Instantiate(ships_small[i], 
                                new Vector3(150f, posY_small[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = Random.Range(5f, 7f);
                    else time_delta = Random.Range(7f, 8f);
                }
                else
                {
                    int i = Random.Range(0,ships_middle.Length);
                    Instantiate(ships_middle[i], 
                                new Vector3(150f, posY_middle[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = Random.Range(6f, 11f);
                    else if (Random.Range(0f, 1f) > 0.5) time_delta = Random.Range(5f, 9f);
                }
            }
            else if (hard <= 10)
            {
                if (shipSpawned + 1 == shipCount && Random.Range(0f,1f)>=0.8f)
                {
                    Instantiate(ships_boss[0], 
                                new Vector3(150f, posY_boss[0], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    return;
                }
                float p = Random.Range(0f,1f);
                if (p <= 0.55f - hard / 60)
                {
                    int i = Random.Range(0,ships_small.Length);
                    Instantiate(ships_small[i], 
                                new Vector3(150f, posY_small[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    time_delta = Random.Range(2f, 4f);
                }
                else if (p <= 0.99f - hard/80)
                {
                    int i = Random.Range(0,ships_middle.Length);
                    Instantiate(ships_middle[i], 
                                new Vector3(150f, posY_middle[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = Random.Range(5f, 6f);
                    else if (Random.Range(0f, 1f) > 0.5) time_delta = Random.Range(4f, 5f);
                    else time_delta = Random.Range(6f, 8f);
                }
                else
                {
                    int i = Random.Range(0,ships_large.Length);
                    Instantiate(ships_large[i], 
                                new Vector3(150f, posY_large[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = Random.Range(6f, 12f);
                    else time_delta = Random.Range(4f, 10f);
                }
            }
            else if (hard <= 15)
            {
                float p = Random.Range(0f,1f);
                if (p <= 0.45f - hard / 60)
                {
                    int i = Random.Range(0,ships_small.Length);
                    Instantiate(ships_small[i], 
                                new Vector3(150f, posY_small[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = -8.5f;
                    else time_delta = Random.Range(-7f, -5f);
                }
                else if (p <= 0.65f - hard/60)
                {
                    int i = Random.Range(0,ships_middle.Length);
                    Instantiate(ships_middle[i], 
                                new Vector3(150f, posY_middle[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = Random.Range(-5f, -2f);
                    else time_delta = -7f;
                }
                else if (Random.Range(0f,1f)<0.8f)
                {
                    int i = Random.Range(0,ships_large.Length);
                    Instantiate(ships_large[i], 
                                new Vector3(150f, posY_large[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    if (Random.Range(0f, 1f) > 0.1) time_delta = Random.Range(1f, 3f);
                    else time_delta = -5f;
                }
                else
                {
                    int i = Random.Range(0,2);
                    Instantiate(ships_boss[i], 
                                new Vector3(150f, posY_boss[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    time_delta = Random.Range(-8f, -7f);
                }
            }
            else
            {
                 float p = Random.Range(0f,1f);
                if (p <= 0.45f - hard / 60)
                {
                    int i = Random.Range(0,ships_small.Length);
                    Instantiate(ships_small[i], 
                                new Vector3(150f, posY_small[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    time_delta = -8.5f;
                }
                else if (p <= 0.55f - hard/60)
                {
                    int i = Random.Range(0,ships_middle.Length);
                    Instantiate(ships_middle[i], 
                                new Vector3(150f, posY_middle[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    time_delta = -7f;
                }
                else if (Random.Range(0f,1f)<0.7f)
                {
                    int i = Random.Range(0,ships_large.Length);
                    Instantiate(ships_large[i], 
                                new Vector3(150f, posY_large[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    time_delta = -5f;
                }
                else
                {
                    int i = Random.Range(0,4);
                    Instantiate(ships_boss[i], 
                                new Vector3(150f, posY_boss[i], 0f), 
                                Quaternion.Euler(0f, 0f, 0f));
                    shipSpawned++;
                    time_delta = Random.Range(-8f, -7f);
                }
            }
        }
    }

}
