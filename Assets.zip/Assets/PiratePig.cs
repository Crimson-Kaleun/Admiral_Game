using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PiratePig : MonoBehaviour
{
    public GameObject Pig;
    private int state = 0;
    private SpriteRenderer PirateAnim;
    public float curHealth = 100f;
    public bool isBoss = false;
    private bool protect = true;
    public Sprite[] Body;
    Quaternion originalPos = Quaternion.Euler(0f, 0f, 0f);

    public AudioClip[] audioHit, audioDead;
    public AudioSource randomSound;

    public bool hasGun;
    public bool autoGun = false;
    public GameObject weapon = null;
    private Animator gunAnim;

    public static int pirateDefeated = 0;

    void Start()
    {
        curHealth = 100f * Mathf.Pow(1.05f, PirateSpawner.hard);
        if (isBoss) curHealth *= 10f;
        PirateAnim = this.GetComponent<SpriteRenderer>();
        setBlink();
        Invoke("unprotect", 0.5f);

        if (hasGun && weapon != null) {
            if (autoGun || Random.Range(0, 10) <=1) {
                gunAnim = weapon.GetComponent<Animator>();
                gunAnim.SetBool("Open", true);
            }
            else {
                hasGun = false;
                Destroy(weapon);
            }
        }
    }

    void unprotect()
    {
        protect = false;
    }

    void setNormal()
    {
        if (state == 0)
        {
            float r = Random.Range(1.5f, 2.2f);
            PirateAnim.sprite = Body[0];
            Invoke("setBlink", r);
        }
    }
    void setBlink()
    {
        if (state == 0) 
        {
            float r = Random.Range(0.3f, 0.8f);
            PirateAnim.sprite = Body[1];
            Invoke("setNormal", r);
        }
    }
    void setState0()
    {
        transform.rotation = originalPos;
        if (hasGun && weapon != null) {
            gunAnim.SetBool("Open", true);
        }
        state = 0;
    }

    void setDamage()
    {
        state = 1;
        if (hasGun && weapon != null) {
            gunAnim.SetBool("Open", false);
        }
        float r = Random.Range(2.3f, 3.8f);
        PirateAnim.sprite = Body[1];
        if (audioHit.Length != 0) randomSound.clip = audioHit[Random.Range(0,audioHit.Length)];
        if (audioHit.Length != 0) randomSound.Play();
        Invoke("setState0", r);
        Invoke("setBlink", r);
    }
    void setDead()
    {
        PlayerPrefs.SetInt("money", PlayerPrefs.GetInt("money", 0) + Random.Range(15,99917));
        pirateDefeated++;
        Body[0] = Body[2]; Body[1] = Body[2];
        PirateAnim.sprite = Body[2];
        if (audioDead.Length != 0) randomSound.clip = audioDead[Random.Range(0,audioDead.Length)];
        if (audioDead.Length != 0) randomSound.Play();
        fade();
    }
    void fade()
    {
        Color tmp = PirateAnim.color;
        tmp.a -= 0.02f;
        if (tmp.a>0.05f) 
        {
            PirateAnim.color = tmp;
            Invoke("fade", 0.01f);
        }
        else {Destroy(Pig); Destroy(Pig.transform.parent.gameObject, 1.2f);}
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
       if (collision.collider.tag == "Pirateship") {
            this.transform.parent.SetParent(collision.transform, true);
       }
       if (protect == true) return;
       float v = collision.relativeVelocity.magnitude;
       if (v<7) v=0;
       float m = collision.gameObject.GetComponent<Rigidbody2D>().mass;
       float k = 1f;
       if (collision.collider.tag == "Cannonball") k = 4f;
       else if (collision.collider.tag == "Shotgunball") k = 3f;
       else if (collision.collider.tag == "BulletRifle") k = 350f;
       else if (collision.collider.tag == "Water") {curHealth -= 999999f; setDead();}
       float dmg = 0.1f * k * Mathf.Sqrt(m * v);
       if (dmg > 1f)
       {
            curHealth -= dmg;
            if (curHealth > 0 && state == 0) setDamage();
            else if (curHealth < 0) setDead();
       }

    }
}
