using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class HealthScript : MonoBehaviour
{
    public Slider healthSlider;
    public Image healthBar;
    public TextMeshProUGUI txt;

    public Sprite[] Bars;
    public GameObject[] Cannons;
    public GameObject fort_skin, Steam, endgame;
    public float maxHealth;
    public int fort;
    // Start is called before the first frame update
    public Sprite[] FORT_SKINS;

    int fx(int index)
    {
        if (index <= 1) return 0;
        if (index <= 5) return 1;
        return 2;
    }
    void checkHealth()
    {
        if (healthSlider.value <= 0f)
        {
           fort_skin.GetComponent<SpriteRenderer>().sprite = FORT_SKINS[fx(fort) + 6];
           fort_skin.GetComponent<PolygonCollider2D>().enabled = false;
           healthBar.enabled = false;
           fort_skin.GetComponent<Rigidbody2D>().gravityScale = 0.4f;
           fort_skin.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
           CannonScript.cannonChosen = -1;
           for (int i=0; i<3; ++i)
           {
               Destroy(Cannons[i]);
           }
           txt.text = "Поражение";
           endgame.SetActive(true);
           endgame.GetComponent<Animator>().SetTrigger("gameover");
        }
        else Invoke("checkHealth", 0.5f);
    }
    void Start()
    {
        fort = PlayerPrefs.GetInt("fort", 0);
        maxHealth = 100f + fort * 25;
        healthSlider.maxValue = maxHealth;
        healthSlider.normalizedValue = 50f;
        healthBar.sprite = Bars[fx(fort)];
        checkHealth();
        endgame.SetActive(false);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
       float v = collision.relativeVelocity.magnitude;
       float m = collision.gameObject.GetComponent<Rigidbody2D>().mass;
       float dmg = 0.1f * Mathf.Sqrt(m * v * v / 2);
       if (dmg > 0.5f && collision.collider.tag == "Pirateball") healthSlider.value -= dmg;
       if (collision.collider.tag == "Pirateship") healthSlider.value = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.S))
        {
            if (healthSlider.value < healthSlider.maxValue)
            {
                healthSlider.value+=1f;
            }
        }
    }
}
