using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipController : MonoBehaviour
{
    public static int shipDrown = 0;
    private float speed = 10f;
    private bool alive = true;
    private int k;

    public AudioClip[] audio_sample;
    public AudioSource audio_source;

    void Start()
    {
        k = PirateCounter(transform, 0);
        if (k==0) k = 1;
        audio_source.clip = audio_sample[Random.Range(0,audio_sample.Length)];
        speed = PirateSpawner.speed;
        Invoke("checkAlive", 0.7f);
    }

    void checkAlive()
    {
        int n = PirateCounter(transform, 0);
        if (PirateCounter(transform, 0) == 0) {alive=false; drown();}
        else Invoke("checkAlive", 0.7f);
    }

    void drown()
    {
        PlayerPrefs.SetInt("money", PlayerPrefs.GetInt("money", 0) + k * k);
        shipDrown++;
        this.GetComponent<Rigidbody2D>().gravityScale = 0.5f;
        this.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
        foreach (Transform t in transform.GetChild(0)) 
        {
             if (t.gameObject.name == "barrel") {
                t.GetComponent<Rigidbody2D>().gravityScale = 0.5f;
                t.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
             }
        }
        audio_source.Play();
        Destroy(gameObject, 1f);
    }

    void Update()
    {
        if (alive) transform.Translate(Vector2.left * Time.deltaTime * speed);
    }

    private int PirateCounter(Transform tr, int num)
    {
        foreach (Transform t in tr) 
        {
             if (t.tag == "Pirate") num++;
             else num += PirateCounter(t, 0);
        }
         return num;
    }
}
