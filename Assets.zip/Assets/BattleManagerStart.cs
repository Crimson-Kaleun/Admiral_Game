using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class BattleManagerStart : MonoBehaviour
{
    public SpriteRenderer fort_skin; //объект
    public SpriteRenderer cannon_01, cannon_02, cannon_03;

    public int FORT_SKIN; //взять из PlayerPrefs код
    public int CANNON_01_SKIN, CANNON_02_SKIN, CANNON_03_SKIN;

    public Sprite[] FORT_SHOP_SKINS, CANNON_SHOP_SKINS;

    int fx(int index)
    {
        if (index <= 1) return 0;
        if (index <= 5) return 1;
        return 2;
    }


    void Start()
    {
    //    fort_skin.alphaHitTestMinimumThreshold = 0.5f;
        FORT_SKIN = PlayerPrefs.GetInt("fort", 0);
        CANNON_01_SKIN = PlayerPrefs.GetInt("cannon01", 0);
        CANNON_02_SKIN = PlayerPrefs.GetInt("cannon02", 5);
        CANNON_03_SKIN = PlayerPrefs.GetInt("cannon03", 0);
        fort_skin.sprite = FORT_SHOP_SKINS[fx(FORT_SKIN)];
        cannon_01.sprite = CANNON_SHOP_SKINS[CANNON_01_SKIN];
        cannon_02.sprite = CANNON_SHOP_SKINS[CANNON_02_SKIN];
        cannon_03.sprite = CANNON_SHOP_SKINS[CANNON_03_SKIN];

        if (CANNON_01_SKIN == 0) {cannon_01.enabled = false;} 
        if (CANNON_02_SKIN == 0) {cannon_02.enabled = false;}
        if (CANNON_03_SKIN == 0) {cannon_03.enabled = false;}

        
    }

}

