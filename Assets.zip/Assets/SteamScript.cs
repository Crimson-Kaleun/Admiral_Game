using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SteamScript : MonoBehaviour
{
    public Sprite[] Steam;
    void Start()
    {
        this.GetComponent<SpriteRenderer>().sprite = Steam[Random.Range(0,Steam.Length)];
        Destroy(this, 1);
    }

    void Update()
    {
         transform.position += Vector3.up * Time.deltaTime;
    }
}
