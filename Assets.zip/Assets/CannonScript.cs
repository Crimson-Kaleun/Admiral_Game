using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CannonScript : MonoBehaviour
{
    public Slider healthSlider;

    public GameObject[] cannons;
    public static int[] cannonsID = {0, 0, 0};
    public static bool[] CanFire = {true, true, true};
    private static float[] timeShot = {1f, 1f, 1f};
    public static int cannonChosen = 0; //0=никакая не выбрана
    private Animator cannonAnim;
    Vector3 difference;

    public GameObject[] AMMO;
    public GameObject Steam;
    public Transform[] shotDir;

    public AudioClip[] gunSounds;
    public AudioSource[] sndSrc; 
    // Start is called before the first frame update
    void Start()
    {
        cannonChosen = -1;
        cannonsID[0] = PlayerPrefs.GetInt("cannon01", 0);
       // cannonsID[1] = PlayerPrefs.GetInt("cannon02", 5);
       cannonsID[1] = 15;
        cannonsID[2] = PlayerPrefs.GetInt("cannon03", 0);
    }

    private void playSound(int t, int type)
    {
        sndSrc[t].clip = gunSounds[Random.Range(0,2) + 3*type];
        sndSrc[t].Play();
    }

    public void chooseCannon(int num)
    {
        if (num > 0  && CanFire[num - 1] && cannonsID[num] != 0)
        {
            cannonChosen = num;
        }
    }


    void shootShotgun()
    {
        int t = (cannonChosen - 1) % 3;
        if (t > 2 || t < 0 || timeShot[t] > 0 || cannonsID[t] == 0) return;
        float k = (cannonsID[t] - 1) % 4;
        cannonAnim = cannons[t].GetComponent<Animator>();
        cannonAnim.Play("Otdacha", 0, 0.25f);
        GameObject bullet = Instantiate(AMMO[0], shotDir[t].position, cannons[t].transform.rotation);
        bullet.GetComponent<Rigidbody2D>().mass *= Mathf.Pow(1.25f, k);
        Destroy(bullet, 5f);
        float vel = 10 * Mathf.Sqrt(Mathf.Max(difference.x, 0f));
        if (vel < 15) vel = 15;
        if (vel > 50) vel = 50;
        bullet.GetComponent<Rigidbody2D>().velocity = (float)1.2*vel*shotDir[t].transform.right;
    }

    void shootCannon()
    {
        int t = (cannonChosen - 1) % 3;
        if (t > 2 || t < 0 || timeShot[t] > 0 || cannonsID[t] == 0) return;
        float k = (cannonsID[t] - 1) % 4;
        if (cannonsID[t] > 8) k += 2;
        cannonAnim = cannons[t].GetComponent<Animator>();
        cannonAnim.Play("Otdacha", 0, 0.25f);
        GameObject a = Instantiate(Steam, shotDir[t].position, cannons[t].transform.rotation);
        Destroy(a, 1f);
        GameObject bullet = Instantiate(AMMO[1], shotDir[t].position, cannons[t].transform.rotation);
        bullet.GetComponent<Rigidbody2D>().mass *= Mathf.Pow(1.35f, k);
        float vel = 16 * Mathf.Sqrt(Mathf.Max(difference.x, 0f));
        if (vel < 15) vel = 15;
        if (vel > 80) vel = 80;
        bullet.GetComponent<Rigidbody2D>().velocity = vel*shotDir[t].transform.right;
        timeShot[t] = 1.5f;
        playSound(t, 1);
    }

    void shootRifle()
    {
        int t = (cannonChosen - 1) % 3;
        if (t > 2 || t < 0 || timeShot[t] > 0 || cannonsID[t] == 0) return;
        float k = (cannonsID[t] - 1) % 4;
        cannonAnim = cannons[t].GetComponent<Animator>();
        cannonAnim.Play("Otdacha", 0, 0.25f);
        GameObject bullet = Instantiate(AMMO[3], shotDir[t].position, cannons[t].transform.rotation);
        bullet.GetComponent<Rigidbody2D>().mass *= Mathf.Pow(1.25f, k);
        Destroy(bullet, 2f);
        float vel = 100;
        bullet.GetComponent<Rigidbody2D>().velocity = vel*shotDir[t].transform.right;
        timeShot[t] = 2f;
        playSound(t, 2);
    }

    void shootGRifle()
    {
        int t = (cannonChosen - 1) % 3;
        if (t > 2 || t < 0 || timeShot[t] > 0 || cannonsID[t] == 0) return;
        float k = (cannonsID[t] - 1) % 4;
        cannonAnim = cannons[t].GetComponent<Animator>();
        cannonAnim.Play("Otdacha", 0, 0.25f);
        GameObject bullet = Instantiate(AMMO[4], shotDir[t].position, cannons[t].transform.rotation);
        bullet.GetComponent<Rigidbody2D>().mass *= Mathf.Pow(1.25f, k);
        Destroy(bullet, 2f);
        float vel = 120;
        bullet.GetComponent<Rigidbody2D>().velocity = vel*shotDir[t].transform.right;
        timeShot[t] = 1.5f;
        playSound(t, 2);
    }
    void Update()
    {
        for (int i = 0; i<3; ++i)
        {
            if (timeShot[i] > 0) timeShot[i] -= Time.deltaTime;
        }

        if (cannonChosen > 0 && healthSlider.value > 0) 
        {
            int t = (cannonChosen - 1) % 3;

            difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - cannons[t].transform.position;
            difference.x -= Camera.main.transform.position.x;
            float rotateZ = Mathf.Atan2(difference.y, Mathf.Abs(difference.x)) * Mathf.Rad2Deg;
            if (rotateZ > 16) rotateZ = 16;
            else if (rotateZ < -16) rotateZ = -16;
            cannons[t].transform.rotation = Quaternion.Euler(0f, 0f, rotateZ);

            if (Input.GetMouseButtonDown(1))
            {
                int ID = cannonsID[t];
                if (ID <= 4)
                {  
                    if (timeShot[t] <= 0f) {
                        for (int i = 0; i<4; ++i) 
                        {
                            shootShotgun();
                        }
                        timeShot[t] = 2.5f;
                        playSound(t, 0);
                    }
                }
                else if (ID <= 8)
                {
                    shootCannon();
                }
                else if (ID <= 12)
                {
                    if (timeShot[t] <= 0f) {
                        shootCannon();
                        timeShot[(cannonChosen - 1) % 3] = 0.4f;
                        Invoke("shootCannon", 0.5f);
                    }
                }
                else if (ID <= 16)
                {
                    shootRifle();
                }
                else
                {
                    shootGRifle();
                }
            }
        }
    }
}
